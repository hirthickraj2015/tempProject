const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

app.use(express.json());
app.use(cors({ origin: 'http://localhost:3000' }));

const mongoURI = process.env.MONGO_URI;
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Schema for user_details collection
const userDetailSchema = new mongoose.Schema({
  userID: String,
  firstName: String,
  lastName: String,
  dob: String,
  mailID: String,
  gender: String,
  role: String // Include the role field
});

// Model for user_details collection
const UserDetails = mongoose.model('user_details', userDetailSchema);

// Schema for login_details collection
const loginDetailSchema = new mongoose.Schema({
  userID: String,
  password: String
});
const LoginDetail = mongoose.model('login_details', loginDetailSchema);

// Route to add a user to the user_details collection
// Route to add a user to the user_details collection
app.post('/add-user', async (req, res) => {
  try {
    const { userID, firstName, lastName, dob, mailID, gender, role } = req.body;
    let defaultPassword = '0000'; // Default password for new user
    const username = userID; // Extract the username before '@'
    
    // Create a new user in UserDetails collection
    const newUser = new UserDetails({ userID, firstName, lastName, dob, mailID, gender, role });
    await newUser.save();
    
    // Create a new login entry for the user in LoginDetail collection
    const newLoginDetail = new LoginDetail({ userID: username, password: defaultPassword });
    await newLoginDetail.save();
    
    res.status(200).json({ message: 'User added successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Route for login
app.post('/login', async (req, res) => {
    try {
      const { userID, password } = req.body;
      const user = await LoginDetail.findOne({ userID, password });
      if (user) {
        // If user exists in login_details collection, fetch role from user_details collection
        const userDetails = await UserDetails.findOne({ userID });
        if (userDetails) {
          const { role } = userDetails;
          res.status(200).json({ message: 'Login successful', role });
        } else {
          res.status(401).json({ error: 'User details not found' });
        }
      } else {
        res.status(401).json({ error: 'Invalid username or password' });
      }
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
