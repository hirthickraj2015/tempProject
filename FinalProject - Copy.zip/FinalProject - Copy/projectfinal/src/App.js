import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Adduser from './components/Adduser';
import Admindashboard from './components/Admindashboard';
import Userdashboard from './components/Userdashboard';
function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route path="/admin" element={<Admindashboard />} />
        <Route path="/addUser" element={<Adduser />} />
        <Route path="/user" element={<Userdashboard />}/>
      </Routes>
    </Router>
  );
}

export default App;
