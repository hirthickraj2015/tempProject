import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate from react-router-dom
import './Login.css'; 

function Login() {
  const [userid, setUserid] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate(); // Initialize useNavigate

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:4000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userID: userid, password })
      });

      if (!response.ok) {
        throw new Error('Invalid username or password');
      }

      // If response is ok, redirect user based on role
      console.log('Login successful!');
      const data = await response.json(); // Parse response JSON
      if (data.role === 'admin') {
        navigate('/admin'); // Redirect to admin dashboard if user is admin
      } else if (data.role === 'user') {
        navigate('/user'); // Redirect to user dashboard if user is not admin
      } else {
        // Handle other roles or redirect to another component if needed
      }
    } catch (error) {
      console.error('Error logging in:', error.message);
      setErrorMessage(error.message);
    }
  };

  const handleForgotPassword = () => {
    // Implement functionality for forgot password action
    console.log('Forgot Password clicked');
    // You can redirect to a forgot password page or show a modal for password reset
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      {errorMessage && <p>{errorMessage}</p>}
      <form onSubmit={handleLogin}>
        <label htmlFor="userid">User ID:</label>
        <input type="text" id="userid" value={userid} onChange={(e) => setUserid(e.target.value)} required />

        <label htmlFor="password">Password:</label>
        <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required />

        <button type="submit">Login</button>
        <button onClick={handleForgotPassword}>Forgot Password</button>
      </form>
      
    </div>
  );
}

export default Login;
