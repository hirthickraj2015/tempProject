import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Adduser from './components/Adduser';
import Admindashboard from './components/Admindashboard';
import Userdashboard from './components/Userdashboard';
import ResetPassword from './components/Resetpassword';
import Resourceallocation from './components/Resourceallocation';
import Addproject from './components/Addproject';
function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route path="/admin" element={<Admindashboard />} />
        <Route path="/addUser" element={<Adduser />} />
        <Route path="/user" element={<Userdashboard />}/>
        <Route path="/resetPassword/:userID" element={<ResetPassword />}/>
        <Route path="/resourceAllocation" element={<Resourceallocation />}/>
        <Route path="/addProject" element={<Addproject />}/>
      </Routes>
    </Router>
  );
}

export default App;
