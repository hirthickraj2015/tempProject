import React from 'react'

function Feedbackhistory() {
  return (
    <div>Feedbackhistory</div>
  )
}

export default Feedbackhistory