import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useHistory
import './Adduser.css';

function Adduser() {
  const [formData, setFormData] = useState({
    userID: '',
    firstName: '',
    lastName: '',
    dob: '',
    mailID: '',
    gender: '',
    role: ''
  });
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate(); // Initialize useHistory

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleAddUser = async () => {
    try {
      const response = await fetch('http://localhost:4000/add-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...formData,
          role: 'user' // Add the role field here
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to add user');
      }

      console.log('User added successfully!');
      setErrorMessage('User added successfully! Please change the password.');
      setTimeout(() => {
        setErrorMessage('');
        navigate('/admin'); // Navigate to admin dashboard route
      }, 3000);
    } catch (error) {
      console.error('Error adding user:', error.message);
      setErrorMessage(error.message);
      if (error.message === 'User already exists') {
      }
    }
  };
  
  
  

  return (
    <div className="admin-container">
      <h2>Admin Panel</h2>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      <div className="form-container">
        <label htmlFor="userID" className="form-label">UserID:</label>
        <input type="text" id="userID" name="userID" value={formData.userID} onChange={handleInputChange} className="form-input" required />

        <label htmlFor="firstName" className="form-label">First Name:</label>
        <input type="text" id="firstName" name="firstName" value={formData.firstName} onChange={handleInputChange} className="form-input" required />

        <label htmlFor="lastName" className="form-label">Last Name:</label>
        <input type="text" id="lastName" name="lastName" value={formData.lastName} onChange={handleInputChange} className="form-input" required />

        <label htmlFor="dob" className="form-label">Date of Birth:</label>
        <input type="text" id="dob" name="dob" value={formData.dob} onChange={handleInputChange} className="form-input" required />

        <label htmlFor="mailID" className="form-label">Email:</label>
        <input type="email" id="mailID" name="mailID" value={formData.mailID} onChange={handleInputChange} className="form-input" required />

        <label htmlFor="gender" className="form-label">Gender:</label>
        <select id="gender" name="gender" value={formData.gender} onChange={handleInputChange} className="form-input" required>
          <option value="">Select</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>

        <label htmlFor="role" className="form-label">Role:</label>
        <select id="role" name="role" value={formData.role} onChange={handleInputChange} className="form-input" required>
          <option value="">Select</option>
          <option value="admin">Admin</option>
          <option value="user">User</option>
        </select>

        <button onClick={handleAddUser} className="form-button">Add User</button>
      </div>
    </div>
  );
}

export default Adduser;
