import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import DatePicker from 'react-datepicker'; // Import DatePicker
import 'react-datepicker/dist/react-datepicker.css'; // Import DatePicker styles
import './Adduser.css';

function Adduser() {
  const [formData, setFormData] = useState({
    userID: '',
    firstName: '',
    lastName: '',
    dob: new Date(), // Set initial date of birth as current date
    mailID: '',
    gender: '',
    role: ''
  });
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleDateChange = (date) => {
    setFormData({
      ...formData,
      dob: date
    });
  };

  const handleAddUser = async () => {
    try {
      const response = await fetch('http://localhost:4000/add-user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...formData,
          dob: formData.dob.toLocaleDateString() // Convert date to string before sending to backend
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to add user');
      }

      setErrorMessage('User added successfully! Please change the password.');
      setTimeout(() => {
        setErrorMessage('');
        navigate('/admin');
      }, 3000);
    } catch (error) {
      console.error('Error adding user:', error.message);
      setErrorMessage(error.message);
    }
  };

  return (
    <div className="container mt-5">
      <div className="card adduser-container">
        <div className="card-body">
          <h2 className="card-title mb-4">Add User</h2>
          {errorMessage && <p className="error-message">{errorMessage}</p>}
          <div className="form-group">
            <label htmlFor="userID" className="form-label">UserID</label>
            <input type="text" id="userID" name="userID" value={formData.userID} onChange={handleInputChange} className="form-control" required />
          </div>

          <div className="form-group">
            <label htmlFor="firstName" className="form-label">First Name</label>
            <input type="text" id="firstName" name="firstName" value={formData.firstName} onChange={handleInputChange} className="form-control" required />
          </div>

          <div className="form-group">
            <label htmlFor="lastName" className="form-label">Last Name</label>
            <input type="text" id="lastName" name="lastName" value={formData.lastName} onChange={handleInputChange} className="form-control" required />
          </div>

          <div className="form-group">
            <label htmlFor="dob" className="form-label">Date of Birth</label>
            <DatePicker
              id="dob"
              name="dob"
              selected={formData.dob}
              onChange={handleDateChange}
              className="form-control"
              dateFormat="yyyy-MM-dd"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="mailID" className="form-label">Email</label>
            <input type="email" id="mailID" name="mailID" value={formData.mailID} onChange={handleInputChange} className="form-control" required />
          </div>

          <div className="form-group">
            <label htmlFor="gender" className="form-label">Gender</label>
            <select id="gender" name="gender" value={formData.gender} onChange={handleInputChange} className="form-control" required>
              <option value="">Select</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="role" className="form-label">Role</label>
            <select id="role" name="role" value={formData.role} onChange={handleInputChange} className="form-control" required>
              <option value="">Select</option>
              <option value="admin">Admin</option>
              <option value="user">User</option>
            </select>
          </div>

          <button onClick={handleAddUser} className="btn btn-primary">Add User</button>
        </div>
      </div>
    </div>
  );
}

export default Adduser;
