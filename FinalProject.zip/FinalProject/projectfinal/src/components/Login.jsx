import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

function Login() {
  const [userid, setUserid] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:4000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userID: userid, password })
      });

      if (!response.ok) {
        throw new Error('Invalid username or password');
      }

      const data = await response.json();
      if (data.role === 'admin') {
        navigate('/admin');
      } else if (data.role === 'user') {
        navigate('/user');
      } else {
        // Handle other roles or redirect to another component if needed
      }
    } catch (error) {
      console.error('Error logging in:', error.message);
      setErrorMessage(error.message);
    }
  };

  const handleForgotPassword = async () => {
    try {
      const response = await fetch('http://localhost:4000/forgotPassword', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ userID: userid })
    });

      if (!response.ok) {
        throw new Error('Failed to send OTP for password reset');
      }

      navigate(`/resetPassword/${userid}`);
    } catch (error) {
      console.error('Error sending OTP for password reset:', error.message);
      setErrorMessage(error.message);
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      {errorMessage && <p>{errorMessage}</p>}
      <form onSubmit={handleLogin}>
        <label htmlFor="userid">User ID:</label>
        <input type="text" id="userid" value={userid} onChange={(e) => setUserid(e.target.value)} required />

        <label htmlFor="password">Password:</label>
        <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required />

        <button type="submit">Login</button>
        <button type="button" onClick={handleForgotPassword} disabled={!userid.trim()}>Forgot Password</button>
      </form>
    </div>
  );
}

export default Login;
