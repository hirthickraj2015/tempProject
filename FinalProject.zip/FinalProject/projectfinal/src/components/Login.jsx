import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

function Login() {
  const [userid, setUserid] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:4000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userID: userid, password })
      });

      if (!response.ok) {
        throw new Error('Invalid username or password');
      }

      const data = await response.json();
      if (data.role === 'admin') {
        navigate('/admin');
      } else if (data.role === 'user') {
        navigate('/user');
      } else {
        // Handle other roles or redirect to another component if needed
      }
    } catch (error) {
      console.error('Error logging in:', error.message);
      setErrorMessage(error.message);
    }
  };

  const handleForgotPassword = async () => {
    try {
      const response = await fetch('http://localhost:4000/forgotPassword', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ userID: userid })
    });

      if (!response.ok) {
        throw new Error('Failed to send OTP for password reset');
      }

      navigate(`/resetPassword/${userid}`);
    } catch (error) {
      console.error('Error sending OTP for password reset:', error.message);
      setErrorMessage(error.message);
    }
  };

  return (
    <div className="container mt-5">
      <div className="card login-container">
        <div className="card-body">
          <h2 className="card-title mb-4">Login</h2>
          {errorMessage && <p className="text-danger">{errorMessage}</p>}
          <form onSubmit={handleLogin}>
            <div className="form-group">
              <label htmlFor="userid">User ID:</label>
              <input type="text" id="userid" value={userid} onChange={(e) => setUserid(e.target.value)} className="form-control" required />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password:</label>
              <input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} className="form-control" required />
            </div>
            <button type="submit" className="btn btn-primary mr-2">Login</button>
            <button type="button" onClick={handleForgotPassword} disabled={!userid.trim()} className="btn btn-secondary">Forgot Password</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
