import React, { useState } from 'react';
import './Timesheet.css';
// Function to handle input change and allow only numbers
const handleInputChange = (event) => {
    const { name, value } = event.target;

    // Only allow numeric input
    const newValue = value.replace(/\D/g, ''); // Remove any non-numeric characters

    // Update state or perform further actions based on the input
};
function Row(){
        <tr className='tda'>
                            <td style={{width:'120px'}}>BAU Activity</td>
                            <td style={{width:'90px'}}><select >
                                <option>BAU_001 Training & Project Knowledge</option>
                                <option>BAU_002 People</option>
                                </select></td>
                            <td style={{width:'90px'}}><select>
                                <option>Employee Wellbeing</option>
                                <option>Jmates</option>
                                </select></td>
                            <td style={{width:'150px'}}><input  type='text'></input></td>
                            <td><div><input type='number' name='hours' /></div></td>                         
                            <td><div><input type='number' name='hours' /></div></td>
                            <td><div><input type='number' name='hours' /></div></td>
                            <td><div><input type='number' name='hours' /></div></td>
                            <td><div><input type='number' name='hours' /></div></td>
                            <td><div><input type='number' name='hours' /></div></td>
                            <td><div><input type='number' name='hours' /></div></td>
                            <td><div><input type='number' name='hours' /></div></td>
                            <td style={{width:'75px'}}><i className='bx bx-plus'></i> <i className='bx bx-minus' ></i></td>
        </tr>
}

export default Row;