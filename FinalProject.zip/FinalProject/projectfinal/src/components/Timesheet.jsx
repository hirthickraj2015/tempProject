import React, { useState, useEffect } from 'react';
import './Timesheet.css';

function Timesheet() {
    const [isCollapsed, setCollapsed] = useState(true);
    const [currentDate, setCurrentDate] = useState(new Date());
    const [rows, setRows] = useState([{ id: 1 }]);
    const [rowCount, setRowCount] = useState(1); // To keep track of the number of rows

    useEffect(() => {
        // Update the current date only once during initial render
        const initialDate = new Date();
        setCurrentDate(initialDate);
    }, []);

    const addRow = () => {
        const newRowId = rowCount + 1;
        setRows([...rows, { id: newRowId }]);
        setRowCount(newRowId);
    };

    const deleteRow = (id) => {
        if (rows.length === 1) {
            // Ensure at least one row is present
            return;
        }
        setRows(rows.filter(row => row.id !== id));
    };

    const handleToggleCollapse = () => {
        setCollapsed(!isCollapsed);
    };

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        const newValue = value.replace(/\D/g, '');
    };

    const formattedDate = (date) => {
        const startOfWeek = new Date(date);
        const endOfWeek = new Date(date);
        
        const startDay = startOfWeek.getDay(); 
        const diff = startOfWeek.getDate() - startDay + (startDay === 0 ? 1 : -6);
        
        startOfWeek.setDate(diff);
        endOfWeek.setDate(diff + 6);
        
        const options = { day: '2-digit', month: 'short', year: 'numeric' };
        return `${startOfWeek.toLocaleDateString('en-US', options)} - ${endOfWeek.toLocaleDateString('en-US', options)}`;
    };
    
    const generateTableHeader = () => {
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const tableHeader = days.map((day, index) => {
            const dayDate = new Date(currentDate);
            const startDay = dayDate.getDay(); // Get the day of the week (0 - Sunday, 1 - Monday, ...)
            const diff = dayDate.getDate() - startDay + (startDay === 0 ? 1 : -6); // Adjust if the current day is Sunday
            dayDate.setDate(diff + index);
            return (
                <th key={index}>
                    <div>{day}</div>
                    <div>{dayDate.getDate()}</div>
                </th>
            );
        });
        return tableHeader;
    };

    const handleNextWeek = () => {
        const nextWeek = new Date(currentDate);
        nextWeek.setDate(nextWeek.getDate() + 7); // Move to the next week
        setCurrentDate(nextWeek);
    };

    const handlePreviousWeek = () => {
        const previousWeek = new Date(currentDate);
        previousWeek.setDate(previousWeek.getDate() - 7); // Move to the previous week
        setCurrentDate(previousWeek);
    };

    return (
        <div>
            <div >
                <div><strong><h2 style={{ marginTop: '20px', fontWeight: 'bold', color: '#19105B' }}>Timesheet</h2></strong></div>
                <div className="dateChange" style={{ fontSize: '14px', textAlign: 'right', paddingRight: '20px' }}>
                    <i className="fa-solid fa-chevron-left" onClick={handlePreviousWeek}></i>{formattedDate(currentDate)}
                    <i className="fa-solid fa-chevron-right" onClick={handleNextWeek}></i>
                </div>
                <div className='allow row'>
                    Allocation Extension
                    <i className='bx bx-chevron-down' style={{ color: 'white' }} onClick={handleToggleCollapse}></i>
                </div>

                <div className={isCollapsed ? 'collapse' : ''}>
                    <div>
                        <table className='tbl'>
                            <tr className='tblhd tbl'>
                                <td>Project Name</td>
                                <td>Project Type</td>
                                <td>Project End Date</td>
                                <td>Allocation End Date</td>
                                <td>Project Allocation Extension</td>
                            </tr>
                            <tr style={{ width: '100%' }} className='tblno'>
                                <td>No Options Available</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div>
                <div className='allow'>Timesheet</div>
                <div>
                    <table className='tbl'>
                        <thead>
                            <tr>
                                <th style={{ width: '120px' }}>Project Type</th>
                                <th style={{ width: '90px' }}>Project Name</th>
                                <th style={{ width: '90px' }}>Task</th>
                                <th style={{ width: '150px' }}>Comment</th>
                                {generateTableHeader()}
                                <th><div>Total</div></th>
                                <th style={{ width: '75px' }}></th>
                            </tr>
                        </thead>
                        <tbody>
                            {rows.map((row, index) => (
                                <tr className='tda' key={row.id}>
                                    <td style={{ width: '120px' }}>
                                        <select>
                                            <option value="">Select Project Type</option>
                                            <option value="bau">BAU Activity</option>
                                            <option value="sales">Sales Activity</option>
                                            {/* Add more options as needed */}
                                        </select>
                                    </td>
                                    <td style={{ width: '90px' }}><select>
                                        <option>BAU_001 Training & Project Knowledge</option>
                                        <option>BAU_002 People</option>
                                    </select></td>
                                    <td style={{ width: '90px' }}><select>
                                        <option>Employee Wellbeing</option>
                                        <option>Jmates</option>
                                    </select></td>
                                    <td style={{ width: '150px' }}><input type='text'></input></td>
                                    {[...Array(7)].map((_, index) => (
                                        <td key={index}><div><input type='number' name='hours' onChange={handleInputChange} /></div></td>
                                    ))}
                                    <td><div><input type='text'></input></div></td>
                                    <td style={{ width: '75px' }}>
                                        {index === 0 ? 
                                            <i className='bx bx-plus' onClick={addRow}></i> :
                                            <i className='bx bx-minus' onClick={() => deleteRow(row.id)}></i>}
                                    </td>
                                </tr>
                            ))}
                            <tr className='tda'>
                                <td style={{ width: '120px' }}>Total Hours</td>
                                <td style={{ width: '90px' }}></td>
                                <td style={{ width: '90px' }}></td>
                                <td style={{ width: '150px' }}></td>
                                <td><div><input type='text'></input></div></td>
                                <td><div><input type='text'></input></div></td>
                                <td><div><input type='text'></input></div></td>
                                <td><div><input type='text'></input></div></td>
                                <td><div><input type='text'></input></div></td>
                                <td><div><input type='text'></input></div></td>
                                <td><div><input type='text'></input></div></td>
                                <td><div><input type='text'></input></div></td>
                                <td style={{ width: '75px' }}></td>
                            </tr>
                            <tr className='tda'>
                                <td style={{ width: '120px' }}>Machine Hours</td>
                                <td style={{ width: '90px' }}></td>
                                <td style={{ width: '90px' }}></td>
                                <td style={{ width: '150px' }}></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><div></div></td>
                                <td style={{ width: '75px' }}></td>
                            </tr>
                            <tr className='tda'>
                                <td style={{ width: '120px' }}>Break Hours</td>
                                <td style={{ width: '90px' }}></td>
                                <td style={{ width: '90px' }}></td>
                                <td style={{ width: '150px' }}></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td style={{ width: '75px' }}></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className='btd'>
                    <button type="button" className="btn btns ">Save</button>
                    <button type="button" className="btn btns1 ">Submit</button>
                </div>
            </div>
        </div>
    );
}

export default Timesheet;
