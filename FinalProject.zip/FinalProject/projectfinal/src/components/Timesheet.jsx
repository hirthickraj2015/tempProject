import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import "./Timesheet.css";

function Timesheet() {
  const [isCollapsed, setCollapsed] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [rows, setRows] = useState([{ id: 1 }]);
  const [rowCount, setRowCount] = useState(1);
  const [resourceAllocationDetails, setResourceAllocationDetails] = useState(
    []
  );
  const [taskDetails, setTaskDetails] = useState({});
  const [projectDetails, setProjectDetails] = useState({});
  const { userID } = useParams();
  const [tableHeaderDates, setTableHeaderDates] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState({});
  const [selectedProjects, setSelectedProjects] = useState({});
  const [selectedTasks, setSelectedTasks] = useState({});
  const [selectedComments, setSelectedComments] = useState({});
  const [Entries, setEntries] = useState([]);
  const [timesheetEntry, setTimesheetEntry] = useState({
    userId: userID,
    start_period: new Date(),
    end_period: new Date(),
    rows: [
      {
        rowId: 1,
        projectId: "",
        taskId: "",
        comments: "",
        mon: 0,
        tue: 0,
        wed: 0,
        thu: 0,
        fri: 0,
        sat: 0,
        sun: 0,
      },
    ], // Initialize rows array
    status: "",
  });
  useEffect(() => {
    const fetchTimesheetEntries = async () => {
      try {
        const startDate = timesheetEntry.start_period.toISOString();
        const endDate = timesheetEntry.end_period.toISOString();

        const response = await fetch(
          `http://localhost:4000/timesheet-entries?userId=${userID}&weekStartDate=${startDate}&weekEndDate=${endDate}`
        );

        if (response.ok) {
          const data = await response.json();
          if (data && Array.isArray(data)) {
            console.log(data); // Log fetched timesheet entries
            // Extract unique entries based on a specific key
            const uniqueData = Array.from(
              new Set(data.map((entry) => entry.projectId))
            ).map((projectId) => {
              return data.find((entry) => entry.projectId === projectId);
            });
            setEntries(uniqueData);
          } else {
            console.error("Data is undefined or not an array");
          }
        } else {
          console.error("Failed to fetch timesheet entries");
        }
      } catch (error) {
        console.error("Error fetching timesheet entries:", error);
      }
    };

    fetchTimesheetEntries();
  }, [userID, timesheetEntry.start_period, timesheetEntry.end_period]);
  console.log(Entries);

  useEffect(() => {
    const startOfWeek = new Date(currentDate);
    const endOfWeek = new Date(currentDate);
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    setTimesheetEntry((prevState) => ({
      ...prevState,
      start_period: startOfWeek,
      end_period: endOfWeek,
    }));
  }, [currentDate]);

  useEffect(() => {
    const fetchResourceAllocationDetails = async () => {
      try {
        const response = await fetch(
          `http://localhost:4000/resource-allocation/${userID}`
        );
        if (response.ok) {
          const data = await response.json();
          if (data && Array.isArray(data)) {
            // Add this check to ensure data is not undefined
            const destructureData = data.map(
              ({ projectId, startDate, endDate }) => ({
                project: projectId,
                resourceStart: startDate,
                resourceEnd: endDate,
              })
            );
            const uniqueProjects = destructureData.filter(
              (project, index, self) =>
                index === self.findIndex((p) => p.project === project.project)
            );
            setResourceAllocationDetails(uniqueProjects);
            uniqueProjects.forEach(async ({ project }) => {
              try {
                const projectResponse = await fetch(
                  `http://localhost:4000/projects/${project}`
                );
                const tasksResponse = await fetch(
                  `http://localhost:4000/tasks/${project}`
                );
                if (projectResponse.ok) {
                  const projectData = await projectResponse.json();
                  setProjectDetails((prevProjectDetails) => ({
                    ...prevProjectDetails,
                    [project]: projectData,
                  }));
                }
                if (tasksResponse.ok) {
                  const tasksData = await tasksResponse.json();
                  setTaskDetails((prevTaskDetails) => ({
                    ...prevTaskDetails,
                    [project]: tasksData,
                  }));
                }
              } catch (error) {
                console.error("Error fetching project or task details:", error);
              }
            });
          } else {
            console.error("Data is undefined or not an array");
          }
        } else {
          console.error("Failed to fetch resource allocation details");
        }
      } catch (error) {
        console.error("Error fetching resource allocation details:", error);
      }
    };

    fetchResourceAllocationDetails();
  }, [userID]);
  useEffect(() => {
    const initialDate = new Date();
    setCurrentDate(initialDate);

    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const currentDate = new Date(initialDate);
    const startDay = currentDate.getDay();
    const diff = currentDate.getDate() - startDay + (startDay === 0 ? -6 : 1);
    const generatedDates = days.map((_, index) => {
      const date = new Date(currentDate);
      date.setDate(diff + index);
      return date.toISOString().split("T")[0];
    });
    setTableHeaderDates(generatedDates);
  }, []);

  const addRow = () => {
    const newRowId = rowCount + 1;
    setRows([...rows, { id: newRowId }]);
    setRowCount(rowCount + 1);
    const newRow = {
      rowId: newRowId,
      projectId: "",
      taskId: "",
      comments: "",
      mon: 0,
      tue: 0,
      wed: 0,
      thu: 0,
      fri: 0,
      sat: 0,
      sun: 0,
    };
    setTimesheetEntry((prevState) => ({
      ...prevState,
      rows: [...(prevState.rows || []), newRow], // Check if prevState.rows exists
    }));
  };

  const deleteRow = (id) => {
    if (rows.length === 1) {
      return;
    }
    setRows(rows.filter((row) => row.id !== id));
    setTimesheetEntry((prevState) => ({
      ...prevState,
      rows: (prevState.rows || []).filter((row) => row.rowId !== id), // Check if prevState.rows exists
    }));
  };

  const handleToggleCollapse = () => {
    setCollapsed(!isCollapsed);
  };

  const formattedDate = (date) => {
    const currentDate = new Date(date);
    const startOfWeek = new Date(currentDate);
    const endOfWeek = new Date(currentDate);

    // Calculate the start of the current week (Sunday)
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 1);

    // Calculate the end of the current week (Saturday)
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    const options = { day: "2-digit", month: "short", year: "numeric" };
    return `${startOfWeek.toLocaleDateString(
      "en-US",
      options
    )} - ${endOfWeek.toLocaleDateString("en-US", options)}`;
  };

  const calculateTotals = () => {
    const totals = Array.from({ length: 8 }, () => 0); // Initialize totals array with zeros for each day plus one for the Total column

    // Calculate totals horizontally (across days)
    rows.forEach((row) => {
      row.total = 0;
      for (let i = 0; i < 7; i++) {
        if (row[`column_${i}`]) {
          totals[i] += row[`column_${i}`];
          row.total += row[`column_${i}`]; // Update row total
          totals[7] += row[`column_${i}`]; // Update Total column
        }
      }
    });

    // Check for conditions and apply styling
    const totalHoursExceeds = totals[7] > 40;
    const horizontalExceeds = totals
      .slice(0, 7)
      .some((dayTotal) => dayTotal > 8);

    return { totals, totalHoursExceeds, horizontalExceeds };
  };

  const { totals, totalHoursExceeds, horizontalExceeds } = calculateTotals();
  useEffect(() => {
    // Generate table header dates
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const currentDate = new Date();
    const startDay = currentDate.getDay();
    const diff = currentDate.getDate() - startDay + (startDay === 0 ? -6 : 1);
    const generatedDates = days.map((_, index) => {
      const date = new Date(currentDate);
      date.setDate(diff + index);
      return date.toISOString().split("T")[0];
    });
    setTableHeaderDates(generatedDates);

    // Generate start and end date based on the current week
    const startOfWeek = new Date(currentDate);
    const endOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 1);
    endOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 7);
    setTimesheetEntry((prevState) => ({
      ...prevState,
      start_period: startOfWeek,
      end_period: endOfWeek,
    }));
  }, []);
  const generateTableHeader = () => {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const tableHeader = days.map((day, index) => {
      const dayDate = new Date(currentDate);
      const startDay = dayDate.getDay();
      const diff =
        dayDate.getDate() - startDay + (startDay === 0 ? -6 : 1) + index; // Adjusted to get the correct date
      dayDate.setDate(diff);
      return (
        <th key={index}>
          <div>{day}</div>
          <div>{dayDate.getDate()}</div>
          {/* Added date as ISO string */}
        </th>
      );
    });
    return tableHeader;
  };

  const uniqueCategories = [
    ...new Set(
      resourceAllocationDetails.map(
        (allocation) => projectDetails[allocation.project]?.category
      )
    ),
  ];

  // Inside the component function
  const handleCategoryChange = (event, rowIndex) => {
    const category = event.target.value;
    setSelectedCategories((prev) => ({ ...prev, [rowIndex]: category }));
  };

  // Adjust handleProjectChange function to update timesheetEntry for each row

  // Inside handleProjectChange function
  const handleProjectChange = (event, rowIndex) => {
    const project = event.target.value;
    setSelectedProjects((prev) => ({ ...prev, [rowIndex]: project }));

    setTimesheetEntry((prevState) => ({
      ...prevState,
      rows: prevState.rows.map((row) =>
        row.rowId === rowIndex + 1 ? { ...row, projectId: project } : row
      ),
    }));
  };

  // Inside handleTaskChange function
  const handleTaskChange = (event, rowIndex) => {
    const task = event.target.value;
    setSelectedTasks((prev) => ({ ...prev, [rowIndex]: task }));

    setTimesheetEntry((prevState) => ({
      ...prevState,
      rows: prevState.rows.map((row) =>
        row.rowId === rowIndex + 1 ? { ...row, taskId: task } : row
      ),
    }));
  };

  const handleCommentsChange = (event, rowIndex) => {
    const comments = event.target.value;

    // Update the selectedComments state
    setSelectedComments((prev) => ({ ...prev, [rowIndex]: comments }));
    // Update the timesheetEntry state
    setTimesheetEntry((prevState) => ({
      ...prevState,
      rows: prevState.rows.map((row) =>
        row.rowId === rowIndex + 1 ? { ...row, comments: comments } : row
      ),
    }));
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;

    const newValue = parseInt(value.replace(/\D/g, ""), 10) || 0; // Parse value as integer, default to 0 if empty or NaN

    // Extract row index and column index from the input name
    const [rowIndex, columnIndex] = name
      .split("_")
      .map((index) => parseInt(index, 10));

    // Update the state of the input value in rows
    const updatedRows = [...rows];
    updatedRows[rowIndex][`column_${columnIndex}`] = newValue;
    setRows(updatedRows);

    // Update the corresponding day (Mon, Tue, Wed, etc.) in timesheetEntry
    const dayOfWeek = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"][
      columnIndex
    ];
    setTimesheetEntry((prevState) => {
      const updatedRows = [...prevState.rows];
      updatedRows[rowIndex][dayOfWeek] = newValue;
      return {
        ...prevState,
        rows: updatedRows,
      };
    });
  };

  const handleNextWeek = () => {
    const nextWeek = new Date(currentDate);
    nextWeek.setDate(nextWeek.getDate() + 7); // Move to the next week
    setCurrentDate(nextWeek);
  };
  // Inside handleSaveOrSubmit function, use timesheetEntry.rows directly
  const handleSaveOrSubmit = async (status) => {
    console.log("status", status); // Log the received status
    try {
      // Increment both start and end period by one day
      const updatedStartPeriod = new Date(timesheetEntry.start_period);
      const updatedEndPeriod = new Date(timesheetEntry.end_period);
      updatedStartPeriod.setDate(updatedStartPeriod.getDate() + 1);
      updatedEndPeriod.setDate(updatedEndPeriod.getDate() + 1);
  
      // Update the timesheet entry with the adjusted dates and status
      const updatedTimesheetEntry = {
        ...timesheetEntry,
        start_period: updatedStartPeriod,
        end_period: updatedEndPeriod,
        status: status, // Include status in the timesheetEntry object
      };
  
      // Log the updated timesheetEntry
      console.log("Updated Timesheet Entry:", updatedTimesheetEntry);
  
      // Send the updated timesheetEntry object
      const response = await fetch(
        "http://localhost:4000/timesheet-entry",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedTimesheetEntry),
        }
      );
  
      // Handle response...
      const responseData = await response.json();
      console.log("Response Data:", responseData); // Log the response data
    } catch (error) {
      console.error(
        `Error ${
          status === "save" ? "saving" : "submitting"
        } timesheet entries:`,
        error
      );
    }
  };

  const handlePreviousWeek = () => {
    const previousWeek = new Date(currentDate);
    previousWeek.setDate(previousWeek.getDate() - 7); // Move to the previous week
    setCurrentDate(previousWeek);
  };
  useEffect(() => {
    // Update the current date only once during initial render
    const initialDate = new Date();
    setCurrentDate(initialDate);

    // Generate table header dates
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const currentDate = new Date(initialDate);
    const startDay = currentDate.getDay();
    const diff = currentDate.getDate() - startDay + (startDay === 0 ? -6 : 1);
    const generatedDates = days.map((_, index) => {
      const date = new Date(currentDate);
      date.setDate(diff + index);
      return date.toISOString().split("T")[0];
    });
    setTableHeaderDates(generatedDates);
  }, []);
  // Inside the Timesheet component function
  useEffect(() => {
    // Iterate through Entries and set selected values
    Entries.forEach((entry) => {
      entry.rows.forEach((row) => {
        const rowIndex = row.rowId - 1; // Adjust row index
        setSelectedCategories((prev) => ({
          ...prev,
          [rowIndex]: projectDetails[entry.projectId]?.category || "",
        }));
        setSelectedProjects((prev) => ({
          ...prev,
          [rowIndex]: entry.projectId,
        }));
        setSelectedTasks((prev) => ({ ...prev, [rowIndex]: row.taskId }));
        setSelectedComments((prev) => ({ ...prev, [rowIndex]: row.comments }));
        // Set hours for each day
        Object.keys(row).forEach((key) => {
          if (key.includes("column_")) {
            const dayIndex = parseInt(key.split("_")[1]);
            const hourValue = row[key];
            const inputName = `${rowIndex}_${dayIndex}`;
            setTimesheetEntry((prevState) => ({
              ...prevState,
              rows: prevState.rows.map((prevRow) => {
                if (prevRow.rowId === row.rowId) {
                  return { ...prevRow, [key]: hourValue };
                }
                return prevRow;
              }),
            }));
          }
        });
      });
    });
  }, [Entries, projectDetails]);
  return (
    <div>
      <div>
        <div>
          <strong>
            <h2
              style={{
                marginTop: "20px",
                fontWeight: "bold",
                color: "#19105B",
              }}
            >
              Timesheet
            </h2>
          </strong>
        </div>
        <div
          className="dateChange"
          style={{ fontSize: "14px", textAlign: "right", paddingRight: "20px" }}
        >
          <i
            className="fa-solid fa-chevron-left"
            onClick={handlePreviousWeek}
          ></i>
          {formattedDate(currentDate)}
          <i className="fa-solid fa-chevron-right" onClick={handleNextWeek}></i>
        </div>
        <div className="allow row" onClick={handleToggleCollapse}>
          Allocation Extension
          <i
            className="bx bx-chevron-down"
            style={{ color: "white" }}
            onClick={handleToggleCollapse}
          ></i>
        </div>

        <div className={isCollapsed ? "collapse" : ""}>
          <div>
            <table className="tbl">
              <thead>
                <tr className="tblhd tbl">
                  <td>Project Name</td>
                  <td>Project Type</td>
                  <td>Project End Date</td>
                  <td>Allocation End Date</td>
                  <td>Project Allocation Extension</td>
                </tr>
              </thead>
              <tbody style={{ backgroundColor: "white" }}>
                {resourceAllocationDetails.length > 0 ? (
                  resourceAllocationDetails.map((allocation, index) => (
                    <tr key={index}>
                      <td>
                        {projectDetails[allocation.project]?.projectName || "-"}
                      </td>
                      <td>
                        {projectDetails[allocation.project]?.category || "-"}
                      </td>
                      <td>
                        {projectDetails[allocation.project]?.endDate || "-"}
                      </td>
                      <td>{allocation.resourceEnd || "-"}</td>
                      <td>-</td>
                    </tr>
                  ))
                ) : (
                  <tr className="tblno">
                    <td colSpan="5">No Projects Available</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div>
        <div className="allow tm">Timesheet</div>
        <div>
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: "120px" }}>Project Type</th>
                <th style={{ width: "90px" }}>Project Name</th>
                <th style={{ width: "90px" }}>Task</th>
                <th style={{ width: "150px" }}>Comment</th>
                {generateTableHeader()}
                <th>
                  <div>Total</div>
                </th>
                <th style={{ width: "75px" }}></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr className="tda" key={row.id}>
                  <td style={{ width: "120px" }}>
                    <select
                      onChange={(e) => handleCategoryChange(e, index)}
                      value={selectedCategories[index] || ""}
                    >
                      <option value="">Select Project Type</option>
                      {uniqueCategories.map((category, index) => (
                        <option key={index} value={category}>
                          {category}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td style={{ width: "90px" }}>
                    <select
                      onChange={(e) => handleProjectChange(e, index)}
                      value={selectedProjects[index] || ""}
                    >
                      <option value="">Select Project Name</option>
                      {resourceAllocationDetails
                        .filter(
                          (allocation) =>
                            projectDetails[allocation.project]?.category ===
                            selectedCategories[index]
                        )
                        .map((allocation, index) => (
                          <option key={index} value={allocation.project}>
                            {projectDetails[allocation.project]?.projectName ||
                              ""}
                          </option>
                        ))}
                    </select>
                  </td>
                  <td style={{ width: "90px" }}>
                    <select
                      onChange={(e) => handleTaskChange(e, index)}
                      value={selectedTasks[index] || ""}
                    >
                      <option value="">Select Task</option>
                      {selectedProjects[index] &&
                        (taskDetails[selectedProjects[index]] || []).map(
                          (task, taskIndex) => (
                            <option key={taskIndex}>{task.task}</option>
                          )
                        )}
                    </select>
                  </td>

                  <td style={{ width: "150px" }}>
                    <input
                      type="text"
                      name={`${index}_comment`}
                      onChange={(e) => handleCommentsChange(e, index)}
                    />
                  </td>
                  {[...Array(7)].map((_, columnIndex) => (
                    <td key={columnIndex} name="timesheethourfilling">
                      <div>
                        <input
                          type="number"
                          name={`${index}_${columnIndex}`}
                          onChange={handleInputChange}
                          value={row[`column_${columnIndex}`] || ""}
                        />
                      </div>
                    </td>
                  ))}

                  {/* Total column */}
                  <td>
                    <input
                      type="text"
                      style={{ border: "none" }}
                      value={row.total}
                      readOnly
                    />
                  </td>

                  <td style={{ width: "75px" }}>
                    {index === 0 ? (
                      <i className="bx bx-plus" onClick={addRow}></i>
                    ) : (
                      <i
                        className="bx bx-minus"
                        onClick={() => deleteRow(row.id)}
                      ></i>
                    )}
                  </td>
                </tr>
              ))}
              <tr className="tda">
                <td style={{ width: "120px" }}>Total Hours</td>
                <td></td>
                <td></td>
                <td></td>
                {[...Array(7)].map((_, index) => (
                  <td key={index}>
                    <input
                      type="text"
                      style={{ border: "none" }}
                      value={totals[index]}
                      readOnly
                    />
                  </td>
                ))}
                <td></td>
                <td style={{ width: "75px" }}></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="btd">
          <button
            type="button"
            className="btn btns"
            onClick={() => handleSaveOrSubmit("save")}
          >
            Save
          </button>
          <button
            type="button"
            className="btn btns1"
            onClick={() => handleSaveOrSubmit("submit")}
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}

export default Timesheet;
