import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import "./Timesheet.css";
import { v4 as uuidv4 } from "uuid";
function Timesheet() {
  const [isCollapsed, setCollapsed] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [rows, setRows] = useState([{ id: 1 }]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedProject, setSelectedProject] = useState("");
  const [rowCount, setRowCount] = useState(1); // To keep track of the number of rows
  const [resourceAllocationDetails, setResourceAllocationDetails] = useState(
    []
  );
  const [taskDetails, setTaskDetails] = useState([]);
  const [projectDetails, setProjectDetails] = useState([]);
  let { userID } = useParams();
  const [tableHeaderDates, setTableHeaderDates] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState({});
  const [selectedProjects, setSelectedProjects] = useState({});
  const [selectedTasks, setSelectedTasks] = useState({});
  const [timesheetEntry, setTimesheetEntry] = useState([{
    rowID: uuidv4(),
    userID: userID,
    PID: "",
    Task: "",
    comments: "",
    start_period: new Date(),
    end_period: new Date(),
    mon: 0,
    tue: 0,
    wed: 0,
    thu: 0,
    fri: 0,
    sat: 0,
    sun: 0,
    status: "", // Will be set dynamically
  }]);

  useEffect(() => {
    const fetchResourceAllocationDetails = async () => {
      try {
        const response = await fetch(
          `http://localhost:4000/resource-allocation/${userID}`
        );
        if (response.ok) {
          const data = await response.json();

          // Dynamically destructure the fetched data
          const destructureData = data.map(
            ({ projectId, startDate, endDate }) => ({
              project: projectId,
              resourceStart: startDate,
              resourceEnd: endDate,
            })
          );

          // Filter out duplicate projects
          const uniqueProjects = destructureData.filter(
            (project, index, self) =>
              index === self.findIndex((p) => p.project === project.project)
          );

          // Update resource allocation details state
          setResourceAllocationDetails(uniqueProjects);

          // Fetch project details and task details for each project
          uniqueProjects.forEach(async ({ project }) => {
            try {
              // Fetch project details
              const projectResponse = await fetch(
                `http://localhost:4000/projects/${project}`
              );
              if (projectResponse.ok) {
                const projectData = await projectResponse.json();
                // Update project details state
                setProjectDetails((prevProjectDetails) => ({
                  ...prevProjectDetails,
                  [project]: projectData,
                }));
              } else {
                console.error(
                  `Failed to fetch project details for project ID ${project}`
                );
              }

              // Fetch task details for the project
              const tasksResponse = await fetch(
                `http://localhost:4000/tasks/${project}`
              );
              if (tasksResponse.ok) {
                const tasksData = await tasksResponse.json();
                // Update task details state
                setTaskDetails((prevTaskDetails) => ({
                  ...prevTaskDetails,
                  [project]: tasksData,
                }));
              } else {
                console.error(
                  `Failed to fetch task details for project ID ${project}`
                );
              }
            } catch (error) {
              console.error("Error fetching project or task details:", error);
            }
          });
        } else {
          console.error("Failed to fetch resource allocation details");
        }
      } catch (error) {
        console.error("Error fetching resource allocation details:", error);
      }
    };

    fetchResourceAllocationDetails();
  }, [userID]);
  console.log(
    "proj:",
    projectDetails,
    "task:",
    taskDetails,
    "reso:",
    resourceAllocationDetails
  );
  useEffect(() => {
    // Update the current date only once during initial render
    const initialDate = new Date();
    setCurrentDate(initialDate);
  }, []);

  const addRow = () => {
    const newRowId = rowCount + 1;
    setRows([...rows, { id: newRowId }]);
    setRowCount(newRowId);
    setTimesheetEntry((prevState) => ({
      ...prevState,
      // Add new row data here
    }));
  };

  const deleteRow = (id) => {
    if (rows.length === 1) {
      // Ensure at least one row is present
      return;
    }
    setRows(rows.filter((row) => row.id !== id));
  };

  const handleToggleCollapse = () => {
    setCollapsed(!isCollapsed);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    const newValue = parseInt(value.replace(/\D/g, ""), 10) || 0; // Parse value as integer, default to 0 if empty or NaN
  
    // Update the state of the input value in rows
    const rowIndex = parseInt(name.split("_")[0], 10);
    const columnIndex = parseInt(name.split("_")[1], 10);
    const updatedRows = [...rows];
    updatedRows[rowIndex][`column_${columnIndex}`] = newValue;
    setRows(updatedRows);
  
    // Update the corresponding day (Mon, Tue, Wed, etc.) in timesheetEntry
    const dayOfWeek = ["mon", "tue", "wed", "thur", "fri", "sat", "sun"][columnIndex];
    setTimesheetEntry((prevState) => ({
      ...prevState,
      [dayOfWeek]: newValue,
    }));
  };

  const formattedDate = (date) => {
    const currentDate = new Date(date);
    const startOfWeek = new Date(currentDate);
    const endOfWeek = new Date(currentDate);

    // Calculate the start of the current week (Sunday)
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 1);

    // Calculate the end of the current week (Saturday)
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    const options = { day: "2-digit", month: "short", year: "numeric" };
    return `${startOfWeek.toLocaleDateString(
      "en-US",
      options
    )} - ${endOfWeek.toLocaleDateString("en-US", options)}`;
  };

  const calculateTotals = () => {
    const totals = Array.from({ length: 8 }, () => 0); // Initialize totals array with zeros for each day plus one for the Total column

    // Calculate totals horizontally (across days)
    rows.forEach((row) => {
      row.total = 0;
      for (let i = 0; i < 7; i++) {
        if (row[`column_${i}`]) {
          totals[i] += row[`column_${i}`];
          row.total += row[`column_${i}`]; // Update row total
          totals[7] += row[`column_${i}`]; // Update Total column
        }
      }
    });

    // Check for conditions and apply styling
    const totalHoursExceeds = totals[7] > 40;
    const horizontalExceeds = totals
      .slice(0, 7)
      .some((dayTotal) => dayTotal > 8);

    return { totals, totalHoursExceeds, horizontalExceeds };
  };

  const { totals, totalHoursExceeds, horizontalExceeds } = calculateTotals();
  useEffect(() => {
    // Generate table header dates
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const currentDate = new Date();
    const startDay = currentDate.getDay();
    const diff = currentDate.getDate() - startDay + (startDay === 0 ? -6 : 1);
    const generatedDates = days.map((_, index) => {
      const date = new Date(currentDate);
      date.setDate(diff + index);
      return date.toISOString().split("T")[0];
    });
    setTableHeaderDates(generatedDates);

    // Generate start and end date based on the current week
    const startOfWeek = new Date(currentDate);
    const endOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 1);
    endOfWeek.setDate(currentDate.getDate() - currentDate.getDay() + 7);
    setTimesheetEntry((prevState) => ({
      ...prevState,
      start_period: startOfWeek,
      end_period: endOfWeek,
    }));
  }, []);
  const generateTableHeader = () => {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const tableHeader = days.map((day, index) => {
      const dayDate = new Date(currentDate);
      const startDay = dayDate.getDay();
      const diff =
        dayDate.getDate() - startDay + (startDay === 0 ? -6 : 1) + index; // Adjusted to get the correct date
      dayDate.setDate(diff);
      return (
        <th key={index}>
          <div>{day}</div>
          <div>{dayDate.getDate()}</div>
          {/* Added date as ISO string */}
        </th>
      );
    });
    return tableHeader;
  };

  const uniqueCategories = [
    ...new Set(
      resourceAllocationDetails.map(
        (allocation) => projectDetails[allocation.project]?.category
      )
    ),
  ];

  // Inside the component function
  const handleCategoryChange = (event, rowIndex) => {
    const category = event.target.value;
    setSelectedCategories((prev) => ({ ...prev, [rowIndex]: category }));
    setTimesheetEntry((prevState) => ({
      ...prevState,
      category: category,
    }));
  };

  const handleProjectChange = (event, rowIndex) => {
    const project = event.target.value;
    setSelectedProjects((prev) => ({ ...prev, [rowIndex]: project }));
    setTimesheetEntry((prevState) => ({
      ...prevState,
      PID: project,
    }));
  };

  const handleTaskChange = (event, rowIndex) => {
    const task = event.target.value;
    setSelectedTasks((prev) => ({ ...prev, [rowIndex]: task }));
    setTimesheetEntry((prevState) => ({
      ...prevState,
      Task: task,
    }));
  };

  const handleCommentsChange = (event) => {
    const comments = event.target.value;
    console.log(comments);
    setTimesheetEntry((prevState) => ({
      ...prevState,
      comments: comments,
    }));
  };

  const handleNextWeek = () => {
    const nextWeek = new Date(currentDate);
    nextWeek.setDate(nextWeek.getDate() + 7); // Move to the next week
    setCurrentDate(nextWeek);
  };
  const handleSave = async () => {
    try {
      // Loop through each row
      for (const row of rows) {
        // Create a new timesheet entry for each row
        const entry = {
          ...timesheetEntry,
          PID: selectedProjects[row.id] || "",
          Task: selectedTasks[row.id] || "",
          category: selectedCategories[row.id] || "",
          comments: row.comments || "",
        };
  
        // Send the entry to the server for saving
        const response = await fetch(
          "http://localhost:4000/save-timesheet-entry",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ ...entry, status: "save" }),
          }
        );
  
        if (response.ok) {
          // Handle success
          console.log("Timesheet entry saved successfully");
        } else {
          console.error("Failed to save timesheet entry");
        }
      }
    } catch (error) {
      console.error("Error saving timesheet entry:", error);
    }
  };
  
  const handleSubmit = async () => {
    console.log("row",rows)
    try {
      // Loop through each row
      for (const row of rows) {
        // Create a new timesheet entry for each row
        const entry = {
          ...timesheetEntry,
          PID: selectedProjects[row.id] || "",
          Task: selectedTasks[row.id] || "",
          category: selectedCategories[row.id] || "",
          comments: row.comments || "",
        };
        console.log("entriesss",entry)
  
        // Send the entry to the server for submission
        const response = await fetch(
          "http://localhost:4000/submit-timesheet-entry",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ ...entry, status: "submit" }),
          }
        );

        console.log("after entriesss", response)
  
        if (response.ok) {
          // Handle success
          console.log("Timesheet entry submitted successfully");
        } else {
          console.error("Failed to submit timesheet entry");
        }
      }
    } catch (error) {
      console.error("Error submitting timesheet entry:", error);
    }
  };
  const handlePreviousWeek = () => {
    const previousWeek = new Date(currentDate);
    previousWeek.setDate(previousWeek.getDate() - 7); // Move to the previous week
    setCurrentDate(previousWeek);
  };
  useEffect(() => {
    // Update the current date only once during initial render
    const initialDate = new Date();
    setCurrentDate(initialDate);

    // Generate table header dates
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const currentDate = new Date(initialDate);
    const startDay = currentDate.getDay();
    const diff = currentDate.getDate() - startDay + (startDay === 0 ? -6 : 1);
    const generatedDates = days.map((_, index) => {
      const date = new Date(currentDate);
      date.setDate(diff + index);
      return date.toISOString().split("T")[0];
    });
    setTableHeaderDates(generatedDates);
  }, []);

  return (
    <div>
      <div>
        <div>
          <strong>
            <h2
              style={{
                marginTop: "20px",
                fontWeight: "bold",
                color: "#19105B",
              }}
            >
              Timesheet
            </h2>
          </strong>
        </div>
        <div
          className="dateChange"
          style={{ fontSize: "14px", textAlign: "right", paddingRight: "20px" }}
        >
          <i
            className="fa-solid fa-chevron-left"
            onClick={handlePreviousWeek}
          ></i>
          {formattedDate(currentDate)}
          <i className="fa-solid fa-chevron-right" onClick={handleNextWeek}></i>
        </div>
        <div className="allow row" onClick={handleToggleCollapse}>
          Allocation Extension
          <i
            className="bx bx-chevron-down"
            style={{ color: "white" }}
            onClick={handleToggleCollapse}
          ></i>
        </div>

        <div className={isCollapsed ? "collapse" : ""}>
          <div>
            <table className="tbl">
              <thead>
                <tr className="tblhd tbl">
                  <td>Project Name</td>
                  <td>Project Type</td>
                  <td>Project End Date</td>
                  <td>Allocation End Date</td>
                  <td>Project Allocation Extension</td>
                </tr>
              </thead>
              <tbody style={{ backgroundColor: "white" }}>
                {resourceAllocationDetails.length > 0 ? (
                  resourceAllocationDetails.map((allocation, index) => (
                    <tr key={index}>
                      <td>
                        {projectDetails[allocation.project]?.projectName || "-"}
                      </td>
                      <td>
                        {projectDetails[allocation.project]?.category || "-"}
                      </td>
                      <td>
                        {projectDetails[allocation.project]?.endDate || "-"}
                      </td>
                      <td>{allocation.resourceEnd || "-"}</td>
                      <td>-</td>
                    </tr>
                  ))
                ) : (
                  <tr className="tblno">
                    <td colSpan="5">No Projects Available</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div>
        <div className="allow tm">Timesheet</div>
        <div>
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: "120px" }}>Project Type</th>
                <th style={{ width: "90px" }}>Project Name</th>
                <th style={{ width: "90px" }}>Task</th>
                <th style={{ width: "150px" }}>Comment</th>
                {generateTableHeader()}
                <th>
                  <div>Total</div>
                </th>
                <th style={{ width: "75px" }}></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr className="tda" key={row.id}>
                  <td style={{ width: "120px" }}>
                    <select
                      onChange={(e) => handleCategoryChange(e, index)}
                      value={selectedCategories[index] || ""}
                    >
                      <option value="">Select Project Type</option>
                      {uniqueCategories.map((category, index) => (
                        <option key={index} value={category}>
                          {category}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td style={{ width: "90px" }}>
                    <select
                      onChange={(e) => handleProjectChange(e, index)}
                      value={selectedProjects[index] || ""}
                    >
                      <option value="">Select Project Name</option>
                      {resourceAllocationDetails
                        .filter(
                          (allocation) =>
                            projectDetails[allocation.project]?.category ===
                            selectedCategories[index]
                        )
                        .map((allocation, index) => (
                          <option key={index} value={allocation.project}>
                            {projectDetails[allocation.project]?.projectName ||
                              ""}
                          </option>
                        ))}
                    </select>
                  </td>
                  <td style={{ width: "90px" }}>
                    <select onChange={(e) => handleTaskChange(e, index)}>
                      <option value="">Select Task</option>
                      {selectedProjects[index] &&
                        (taskDetails[selectedProjects[index]] || []).map(
                          (task, taskIndex) => (
                            <option key={taskIndex}>{task.task}</option>
                          )
                        )}
                    </select>
                  </td>

                  <td style={{ width: "150px" }}>
                    <input type="text" onChange={handleCommentsChange}></input>
                  </td>
                  {[...Array(7)].map((_, columnIndex) => (
                    <td key={columnIndex} name="timesheethourfilling">
                      <div>
                        <input
                          type="number"
                          name={`${index}_${columnIndex}`}
                          onChange={handleInputChange}
                          value={row[`column_${columnIndex}`] || ""}
                          disabled={
                            (resourceAllocationDetails[index] &&
                              new Date() >
                                new Date(
                                  resourceAllocationDetails[index].resourceEnd
                                )) || // Current date is after resource end date
                            (resourceAllocationDetails[index] &&
                              new Date(tableHeaderDates[columnIndex]) >
                                new Date(
                                  resourceAllocationDetails[index].resourceEnd
                                )) // Table header date is after resource end date
                          }
                        />
                      </div>
                    </td>
                  ))}

                  {/* Total column */}
                  <td>
                    <input
                      type="text"
                      style={{ border: "none" }}
                      value={row.total}
                      readOnly
                    />
                  </td>

                  <td style={{ width: "75px" }}>
                    {index === 0 ? (
                      <i className="bx bx-plus" onClick={addRow}></i>
                    ) : (
                      <i
                        className="bx bx-minus"
                        onClick={() => deleteRow(row.id)}
                      ></i>
                    )}
                  </td>
                </tr>
              ))}
              <tr className="tda">
                <td style={{ width: "120px" }}>Total Hours</td>
                <td></td>
                <td></td>
                <td></td>
                {[...Array(7)].map((_, index) => (
                  <td key={index}>
                    <input
                      type="text"
                      style={{ border: "none" }}
                      value={totals[index]}
                      readOnly
                    />
                  </td>
                ))}
                <td></td>
                <td style={{ width: "75px" }}></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="btd">
          <button type="button" className="btn btns" onClick={handleSave}>
            Save
          </button>
          <button type="button" className="btn btns1" onClick={handleSubmit}>
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}

export default Timesheet;
