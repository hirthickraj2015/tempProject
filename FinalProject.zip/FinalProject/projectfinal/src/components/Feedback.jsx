import React from 'react'

function Feedback() {
  return (
    <div>Feedback</div>
  )
}

export default Feedback