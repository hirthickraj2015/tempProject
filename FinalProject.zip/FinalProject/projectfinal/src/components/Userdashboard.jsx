import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom'; // Import useParams
import './Userdashboard.css';
import timesheeticon from '../assets/timesheeticon.gif';
import feedback from '../assets/feedback.gif';
import feedbackhistory from '../assets/feedbackhistory.gif';
import projectstatus from '../assets/projectstatus.gif';

function Userdashboard() {
  const [isNavOpen, setIsNavOpen] = useState(true);
  const { userID } = useParams(); // Retrieve userID from URL params

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 600 && isNavOpen) {
        setIsNavOpen(false); // Close the nav on resize if it's open
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [isNavOpen]); // Listen to changes in isNavOpen state

  const toggleNav = () => {
    setIsNavOpen(!isNavOpen);
  };

  return (
    <div>
      <button className='sidebar-toggle dagg' onClick={toggleNav}>
        <span className="material-symbols-outlined">{isNavOpen ? "toggle_on" : "toggle_off"}</span>
      </button>
      <nav className={`nav ${isNavOpen ? "nav-open" : "nav-close"}`}>
        <div className='logo'>Timesheet</div>
        <ul>
          <li>
            <a className='timesheet links' href="#"><img src={timesheeticon} alt="Timesheet Icon" className='nav-icons'></img>Timesheet</a>
          </li>
          <li>
            <a className='feedback links' href="#"><img src={feedback} alt="Feedback Icon" className='nav-icons'></img>Feedback</a>
          </li>
          <li>
            <a className='feedback-history links' href="#"><img src={feedbackhistory} alt="Feedback History Icon" className='nav-icons'></img>Feedback History</a>
          </li>
          <li>
            <a className='project-status links' href="#"><img src={projectstatus} alt="Project Status Icon" className='nav-icons'></img>Project Status</a>
          </li>
        </ul>
      </nav>
      <div className='content' style={{ left: isNavOpen ? '250px' : '0' }}>
        Hi, UserID: {userID} {/* Display the userID */}
      </div>
    </div>
  );
}

export default Userdashboard;
