import React from 'react';

function Userdashboard() {
  return (
    <div className="user-dashboard">
      <h2>Hello User</h2>
    </div>
  );
}

export default Userdashboard;
