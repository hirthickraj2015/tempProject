import React from 'react';
import { useNavigate, useParams } from 'react-router-dom'; // Import useParams
import './Admindashboard.css'

function Admindashboard() {
  const navigate = useNavigate();
  const { userID } = useParams(); // Retrieve userID from URL params
  
  const handleAddUser = () => {
    navigate(`/addUser/${userID}`); // Include userID in the link
  };

  const handleAddProject = () => {
    navigate(`/addProject/${userID}`); // Include userID in the link
  };

  const handleResourceAllocation = () => {
    navigate(`/resourceAllocation/${userID}`); // Include userID in the link
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <button onClick={handleAddUser}>Add User</button>
      <button onClick={handleAddProject}>Add Project</button>
      <button onClick={handleResourceAllocation}>Resource Allocation</button>
    </div>
  );
}

export default Admindashboard;
