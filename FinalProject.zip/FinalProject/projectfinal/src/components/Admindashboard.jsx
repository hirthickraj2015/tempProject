import React from 'react';
import { useNavigate } from 'react-router-dom';

function Admindashboard() {
  const navigate = useNavigate();

  const handleAddUser = () => {
    navigate('/addUser');
  };

  const handleAddProject = () => {
    navigate('/addProject'); // Assuming '/addProject' is the route for adding a new project
  };

  const handleResourceAllocation = () => {
    navigate('/resourceAllocation'); // Assuming '/resourceAllocation' is the route for resource allocation
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <button onClick={handleAddUser}>Add User</button>
      <button onClick={handleAddProject}>Add Project</button>
      <button onClick={handleResourceAllocation}>Resource Allocation</button>
    </div>
  );
}

export default Admindashboard;
