import React from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

function Admindashboard() {
  const navigate = useNavigate(); // Initialize useNavigate

  const handleAddUser = () => {
    navigate('/addUser'); // Redirect to AddUser component using useNavigate
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <button onClick={handleAddUser}>Add User</button>
    </div>
  );
}

export default Admindashboard;