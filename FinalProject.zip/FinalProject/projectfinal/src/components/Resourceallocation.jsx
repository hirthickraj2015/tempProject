import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Addproject.css'
function ResourceAllocation() {
  const [projects, setProjects] = useState([]);
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    projectId: '',
    userIds: [],
    startDate: '',
    endDate: ''
  });

  useEffect(() => {
    // Fetch projects
    axios.get('http://localhost:4000/projects')
      .then(response => {
        setProjects(response.data);
      })
      .catch(error => {
        console.error('Error fetching projects:', error);
      });

    // Fetch users
    axios.get('http://localhost:4000/users')
      .then(response => {
        setUsers(response.data);
      })
      .catch(error => {
        console.error('Error fetching users:', error);
      });
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleUserSelection = (e) => {
    const { options } = e.target;
    const selectedUserIds = [];
    for (let i = 0; i < options.length; i++) {
      if (options[i].selected) {
        selectedUserIds.push(options[i].value);
      }
    }
    setFormData({
      ...formData,
      userIds: selectedUserIds
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your form submission logic here
    console.log(formData);
  
    // Send the form data to the backend
    axios.post('http://localhost:4000/allocate-resources', formData)
      .then(response => {
        console.log('Resource allocation successful:', response.data);
        // Reset form data after successful submission
        setFormData({
          projectId: '',
          userIds: [],
          startDate: '',
          endDate: ''
        });
      })
      .catch(error => {
        console.error('Error allocating resources:', error);
        // Handle error if needed
      });
  };
  

  return (
    <div className="container">
      <h2>Resource Allocation</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="projectId">Project ID:</label>
          <select id="projectId" name="projectId" value={formData.projectId} onChange={handleInputChange} className="form-control" required>
            <option value="">Select Project ID</option>
            {projects.map(project => (
              <option key={project._id} value={project.projectId}>{project.projectId}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="userIds">Select Users:</label>
          <select id="userIds" name="userIds" multiple value={formData.userIds} onChange={handleUserSelection} className="form-control" required>
            {users.map(user => (
              <option key={user._id} value={user.userID}>{user.userID}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="startDate">Start Date:</label>
          <input type="date" id="startDate" name="startDate" value={formData.startDate} onChange={handleInputChange} className="form-control" required />
        </div>
        <div className="form-group">
          <label htmlFor="endDate">End Date:</label>
          <input type="date" id="endDate" name="endDate" value={formData.endDate} onChange={handleInputChange} className="form-control" required />
        </div>
        <button type="submit" className="btn btn-primary">Allocate Resources</button>
      </form>
    </div>
  );
}

export default ResourceAllocation;
