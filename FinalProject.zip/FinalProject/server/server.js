const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const nodemailer = require('nodemailer'); // Import nodemailer
require('dotenv').config();

const app = express();

app.use(express.json());
app.use(cors({ origin: 'http://localhost:3000' }));

const mongoURI = process.env.MONGO_URI;
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Nodemailer configuration
const transporter = nodemailer.createTransport({
  service: 'Gmail', // Update with your email service provider (e.g., Gmail)
  auth: {
    user: 'hirthickraj2015@gmail.com', // Update with your email address
    pass: 'qqgo exwu daqk zljb' // Update with your email password
  }
});

// Schema for user_details collection
const userDetailSchema = new mongoose.Schema({
  userID: String,
  firstName: String,
  lastName: String,
  dob: String,
  mailID: String,
  gender: String,
  role: String // Include the role field
});

// Model for user_details collection
const UserDetails = mongoose.model('user_details', userDetailSchema);

// Schema for login_details collection
const loginDetailSchema = new mongoose.Schema({
  userID: String,
  password: String,
  otp: Number // Change the type to Number for OTP
});
const LoginDetail = mongoose.model('login_details', loginDetailSchema);

// Route to add a user to the user_details collection
app.post('/add-user', async (req, res) => {
  try {
    const { userID, firstName, lastName, dob, mailID, gender, role } = req.body;

    // Check if the user already exists
    const existingUser = await UserDetails.findOne({ userID });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    let defaultPassword = '0000'; // Default password for new user
    
    // Generate a random 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000);
    
    // Create a new user in UserDetails collection
    const newUser = new UserDetails({ userID, firstName, lastName, dob, mailID, gender, role });
    await newUser.save();
    
    // Create a new login entry for the user in LoginDetail collection with generated OTP
    const newLoginDetail = new LoginDetail({ userID, password: defaultPassword, otp });
    await newLoginDetail.save();
    
    // Send email with OTP and reset password link
    const mailOptions = {
      from: 'hirthickraj2015@gmail.com', // Update with your email address
      to: mailID,
      subject: 'Password Reset OTP',
      text: `Your OTP for password reset is: ${newLoginDetail.otp}. Click on the following link to reset your password: http://localhost:3000/resetPassword/${userID}`
    };
    
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
      } else {
        console.log('Email sent:', info.response);
      }
    });
    
    res.status(200).json({ message: 'User added successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Route for login
app.post('/login', async (req, res) => {
  try {
    const { userID, password } = req.body;
    const user = await LoginDetail.findOne({ userID, password });
    if (user) {
      // If user exists in login_details collection, fetch role from user_details collection
      const userDetails = await UserDetails.findOne({ userID });
      if (userDetails) {
        const { role } = userDetails;
        res.status(200).json({ message: 'Login successful', role });
      } else {
        res.status(401).json({ error: 'User details not found' });
      }
    } else {
      res.status(401).json({ error: 'Invalid username or password' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Route to handle forgot password requests
app.post('/forgotPassword', async (req, res) => {
  try {
    const { userID } = req.body;
    // Generate a new OTP
    const newOTP = Math.floor(100000 + Math.random() * 900000);
    // Update the OTP in the database
    await LoginDetail.updateOne({ userID }, { otp: newOTP });
    // Fetch user details to get email address
    const userDetails = await UserDetails.findOne({ userID });
    if (!userDetails) {
      return res.status(404).json({ error: 'User not found' });
    }
    // Send email with new OTP
    const mailOptions = {
      from: 'hirthickraj2015@gmail.com',
      to: userDetails.mailID,
      subject: 'Password Reset OTP',
      text: `Your OTP for password reset is: ${newOTP}. Click on the following link to reset your password: http://localhost:3000/resetPassword/${userID}`
    };
    transporter.sendMail(mailOptions, async (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
        return res.status(500).json({ error: 'Failed to send OTP email' });
      }
      console.log('Email sent:', info.response);
      // Store the OTP in the database
      const user = await LoginDetail.findOne({ userID });
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      user.otp = newOTP;
      await user.save();
      return res.status(200).json({ message: 'OTP sent successfully' });
    });
  } catch (error) {
    console.error('Error generating OTP:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Backend Route for resetting password
app.post('/resetPassword', async (req, res) => {
  try {
    const { userID, otp, newPassword } = req.body;
     // Log userID to check if it's received correctly
    // Find the user in the login_details collection
    console.log(userID)
    const user = await LoginDetail.findOne({ userID });
    if (!user) {
      console.log(user)
      return res.status(404).json({ error: 'User not found' });
    }
    // Check if the provided OTP matches the stored OTP
    const otp2=parseInt(otp,10)
    if (user.otp !== otp2) {
      console.log(user.otp,otp2)
      return res.status(400).json({ error: 'Incorrect OTP' });
    }

    // Update the user's password with the new password
    user.password = newPassword;
    await user.save();

    res.status(200).json({ message: 'Password reset successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Schema for project_details collection
const projectDetailSchema = new mongoose.Schema({
  projectName: String,
  projectId: { type: String, unique: true }, // Make projectId unique
  category: String,
  startDate: String,
  endDate: String,
});

// Model for project_details collection
const ProjectDetails = mongoose.model('project_details', projectDetailSchema);

// Route to add a project to the project_details collection
app.post('/add-project', async (req, res) => {
  try {
    const { projectName, projectId, category, startDate, endDate, tasks } = req.body;

    // Check if the projectId already exists
    const existingProject = await ProjectDetails.findOne({ projectId });
    if (existingProject) {
      return res.status(400).json({ error: 'Project ID already exists' });
    }

    // Create a new project in ProjectDetails collection
    const newProject = new ProjectDetails({ projectName, projectId, category, startDate, endDate });
    await newProject.save();

    // Save tasks associated with the project
    await Promise.all(tasks.map(async (task) => {
      const newTask = new ProjectTask({ projectId, task });
      await newTask.save();
    }));

    res.status(200).json({ message: 'Project added successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Schema for resource allocation
// Schema for resource allocation
const resourceAllocationSchema = new mongoose.Schema({
  projectId: String,
  userId: String, // Change to a single userId field
  startDate: String,
  endDate: String,
});


// Model for resource allocation
const ResourceAllocation = mongoose.model('resource_allocation', resourceAllocationSchema);

// Route to handle resource allocation
app.post('/allocate-resources', async (req, res) => {
  try {
    const { projectId, userId, startDate, endDate, allocatedBy } = req.body;

    // Check if the project exists
    const existingProject = await ProjectDetails.findOne({ projectId });
    if (!existingProject) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Create a new resource allocation entry
    const newAllocation = new ResourceAllocation({ projectId, userId, startDate, endDate });
    await newAllocation.save();

    res.status(200).json({ message: 'Resource allocation successful' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
app.get('/resource-allocation/:userId', async (req, res) => {
  try {
      const userId = req.params.userId;
      const resourceAllocations = await ResourceAllocation.find({ userId });
      res.json(resourceAllocations);
  } catch (error) {
      console.error('Error fetching resource allocation details:', error);
      res.status(500).json({ error: 'Internal server error' });
  }
});
// Route to fetch projects
app.get('/projects', async (req, res) => {
  try {
    const projects = await ProjectDetails.find();
    res.status(200).json(projects);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Route to fetch users
app.get('/users', async (req, res) => {
  try {
    const users = await UserDetails.find();
    res.status(200).json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Schema for project tasks
const projectTaskSchema = new mongoose.Schema({
  projectId: String,
  task: String
});

// Model for project tasks
const ProjectTask = mongoose.model('project_tasks', projectTaskSchema);

// Route to add tasks for a project
app.post('/add-project-task', async (req, res) => {
  try {
    const { projectId, task } = req.body;

    // Create a new project task entry
    const newTask = new ProjectTask({ projectId, task });
    await newTask.save();

    res.status(200).json({ message: 'Project task added successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Route to fetch project details by project ID
app.get('/projects/:projectId', async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const project = await ProjectDetails.findOne({ projectId });
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }
    res.status(200).json(project);
  } catch (error) {
    console.error('Error fetching project details:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Route to fetch tasks by project ID
app.get('/tasks/:projectId', async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const tasks = await ProjectTask.find({ projectId });
    if (!tasks) {
      return res.status(404).json({ error: 'Tasks not found' });
    }
    res.status(200).json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Schema for timesheet entries
const timesheetEntrySchema = new mongoose.Schema({
  rowID: { type: String, unique: true }, // Unique randomly generated row ID
  userID: String,
  PID: String,
  Task: String,
  comments: String,
  start_period: Date,
  end_period: Date,
  mon: Number,
  tue: Number,
  wed: Number,
  thur: Number,
  fri: Number,
  sat: Number,
  sun: Number,
  status: String, // Status can be 'save' or 'submit'
});

// Model for timesheet entries
const TimesheetEntry = mongoose.model('timesheet_entries', timesheetEntrySchema);
// Route to save timesheet entry
app.post('/save-timesheet-entry', async (req, res) => {
  console.log("backend timesheet entry",req.body)
  {req.body[0].rowID,req.body[0].rowID}
  try {
    const entryData = req.body;
    // Create a new timesheet entry
    const newEntry = new TimesheetEntry(entryData);
    newEntry.status = 'save'; // Set status as 'save'
    await newEntry.save();
    res.status(200).json({ message: 'Timesheet entry saved successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Route to submit timesheet entry
app.post('/submit-timesheet-entry', async (req, res) => {
  try {
    const entryData = req.body;
    // Create a new timesheet entry
    const newEntry = new TimesheetEntry(entryData);
    newEntry.status = 'submit'; // Set status as 'submit'
    await newEntry.save();
    res.status(200).json({ message: 'Timesheet entry submitted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});



const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


