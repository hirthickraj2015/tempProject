const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const nodemailer = require('nodemailer'); // Import nodemailer
require('dotenv').config();

const app = express();

app.use(express.json());
app.use(cors({ origin: 'http://localhost:3000' }));

const mongoURI = process.env.MONGO_URI;
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Nodemailer configuration
const transporter = nodemailer.createTransport({
  service: 'Gmail', // Update with your email service provider (e.g., Gmail)
  auth: {
    user: 'hirthickraj2015@gmail.com', // Update with your email address
    pass: 'qqgo exwu daqk zljb' // Update with your email password
  }
});

// Schema for user_details collection
const userDetailSchema = new mongoose.Schema({
  userID: String,
  firstName: String,
  lastName: String,
  dob: String,
  mailID: String,
  gender: String,
  role: String // Include the role field
});

// Model for user_details collection
const UserDetails = mongoose.model('user_details', userDetailSchema);

// Schema for login_details collection
const loginDetailSchema = new mongoose.Schema({
  userID: String,
  password: String,
  otp: Number // Change the type to Number for OTP
});
const LoginDetail = mongoose.model('login_details', loginDetailSchema);

// Route to add a user to the user_details collection
app.post('/add-user', async (req, res) => {
  try {
    const { userID, firstName, lastName, dob, mailID, gender, role } = req.body;

    // Check if the user already exists
    const existingUser = await UserDetails.findOne({ userID });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    let defaultPassword = '0000'; // Default password for new user
    
    // Generate a random 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000);
    
    // Create a new user in UserDetails collection
    const newUser = new UserDetails({ userID, firstName, lastName, dob, mailID, gender, role });
    await newUser.save();
    
    // Create a new login entry for the user in LoginDetail collection with generated OTP
    const newLoginDetail = new LoginDetail({ userID, password: defaultPassword, otp });
    await newLoginDetail.save();
    
    // Send email with OTP and reset password link
    const mailOptions = {
      from: 'hirthickraj2015@gmail.com', // Update with your email address
      to: mailID,
      subject: 'Password Reset OTP',
      text: `Your OTP for password reset is: ${newLoginDetail.otp}. Click on the following link to reset your password: http://localhost:3000/resetPassword/${userID}`
    };
    
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
      } else {
        console.log('Email sent:', info.response);
      }
    });
    
    res.status(200).json({ message: 'User added successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});


// Route for login
app.post('/login', async (req, res) => {
  try {
    const { userID, password } = req.body;
    const user = await LoginDetail.findOne({ userID, password });
    if (user) {
      // If user exists in login_details collection, fetch role from user_details collection
      const userDetails = await UserDetails.findOne({ userID });
      if (userDetails) {
        const { role } = userDetails;
        res.status(200).json({ message: 'Login successful', role });
      } else {
        res.status(401).json({ error: 'User details not found' });
      }
    } else {
      res.status(401).json({ error: 'Invalid username or password' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Route to handle forgot password requests
app.post('/forgotPassword', async (req, res) => {
  try {
    const { userID } = req.body;
    // Generate a new OTP
    const newOTP = Math.floor(100000 + Math.random() * 900000);
    // Update the OTP in the database
    await LoginDetail.updateOne({ userID }, { otp: newOTP });
    // Fetch user details to get email address
    const userDetails = await UserDetails.findOne({ userID });
    if (!userDetails) {
      return res.status(404).json({ error: 'User not found' });
    }
    // Send email with new OTP
    const mailOptions = {
      from: 'hirthickraj2015@gmail.com',
      to: userDetails.mailID,
      subject: 'Password Reset OTP',
      text: `Your OTP for password reset is: ${newOTP}. Click on the following link to reset your password: http://localhost:3000/resetPassword/${userID}`
    };
    transporter.sendMail(mailOptions, async (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
        return res.status(500).json({ error: 'Failed to send OTP email' });
      }
      console.log('Email sent:', info.response);
      // Store the OTP in the database
      const user = await LoginDetail.findOne({ userID });
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      user.otp = newOTP;
      await user.save();
      return res.status(200).json({ message: 'OTP sent successfully' });
    });
  } catch (error) {
    console.error('Error generating OTP:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Backend Route for resetting password
app.post('/resetPassword', async (req, res) => {
  try {
    const { userID, otp, newPassword } = req.body;
     // Log userID to check if it's received correctly
    // Find the user in the login_details collection
    console.log(userID)
    const user = await LoginDetail.findOne({ userID });
    if (!user) {
      console.log(user)
      return res.status(404).json({ error: 'User not found' });
    }
    // Check if the provided OTP matches the stored OTP
    const otp2=parseInt(otp,10)
    if (user.otp !== otp2) {
      console.log(user.otp,otp2)
      return res.status(400).json({ error: 'Incorrect OTP' });
    }

    // Update the user's password with the new password
    user.password = newPassword;
    await user.save();

    res.status(200).json({ message: 'Password reset successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Schema for project_details collection
const projectDetailSchema = new mongoose.Schema({
  projectName: String,
  projectId: { type: String, unique: true }, // Make projectId unique
  category: String,
  startDate: String,
  endDate: String,
});

// Model for project_details collection
const ProjectDetails = mongoose.model('project_details', projectDetailSchema);

// Route to add a project to the project_details collection
app.post('/add-project', async (req, res) => {
  try {
    const { projectName, projectId, category, startDate, endDate} = req.body;

    // Check if the projectId already exists
    const existingProject = await ProjectDetails.findOne({ projectId });
    if (existingProject) {
      return res.status(400).json({ error: 'Project ID already exists' });
    }

    // Create a new project in ProjectDetails collection
    const newProject = new ProjectDetails({ projectName, projectId, category, startDate, endDate });
    await newProject.save();
    
    res.status(200).json({ message: 'Project added successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Schema for resource allocation
const resourceAllocationSchema = new mongoose.Schema({
  projectId: String,
  userIds: [String],
  startDate: String,
  endDate: String,
  allocatedBy: String // Admin user ID who allocated the resources
});

// Model for resource allocation
const ResourceAllocation = mongoose.model('resource_allocation', resourceAllocationSchema);

// Route to handle resource allocation
app.post('/allocate-resources', async (req, res) => {
  try {
    const { projectId, userIds, startDate, endDate, allocatedBy } = req.body;

    // Check if the project exists
    const existingProject = await ProjectDetails.findOne({ projectId });
    if (!existingProject) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Create a new resource allocation entry
    const newAllocation = new ResourceAllocation({ projectId, userIds, startDate, endDate, allocatedBy });
    await newAllocation.save();

    res.status(200).json({ message: 'Resource allocation successful' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});
// Route to fetch projects
app.get('/projects', async (req, res) => {
  try {
    const projects = await ProjectDetails.find();
    res.status(200).json(projects);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Route to fetch users
app.get('/users', async (req, res) => {
  try {
    const users = await UserDetails.find();
    res.status(200).json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));


/*"Project Problem Statement: Timesheet and Feedback System

Overview:
This project aims to simplify the process of timesheet creation and feedback submission for employees. 
Both tasks will be made mandatory. Feedback questions will be tailored based on employees' roles and the projects they're working on.

Key Features:

Timesheet Creation:

Employees can easily create and submit timesheets, detailing their work hours and tasks completed.
Feedback Question Creation:

Administrators can create feedback questions based on employees' roles and project involvement.
Mandatory Submission:

Both timesheet and feedback submissions are mandatory. Submitting a timesheet will redirect employees to provide feedback.
Role-Based Access:

Access to timesheets and feedback features is controlled based on employees' roles.
Project-Specific Feedback:

Feedback questions are customized based on the project an employee is working on.
Automated Reminders:

Automated notifications remind employees of pending timesheets and feedback submissions."

"Data engineering COE - Platform build:
The goal is to setup a data platform which allows to connect to source system and Desing and build a data model that satisfies the reporting needs(Mostly operational reports to Govern/improve the business operations for above requirements)

- Connect and extract data from all source systems 

- Clean , Tranform, Design and Build Data model , Build reporting tables with proper data grovenance and secutiry measures in place(Potentially using DBT core & snowflake)

- Automate to reduce/remove manual interventions"			
			

Based on employee timesheets, predict which is employee is likely to need an attendance regularization

*/